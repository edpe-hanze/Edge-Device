

Please place/verify the file "platform_data.py" in the below path
>> azure-iot-sdk-python/tools/platform_data.py

Run the below commands to run the "platform_data.py" file
================================================================

1) Install the python
 >> sudo apt-get install python

2) Install the below modules
 >> sudo apt-get install python-requests

 >> sudo apt-get install python-netifaces

3) Run the "platform_data.py" file and verify the output on prompt
 >> python platform_data.py







